#ifndef ENGINE_H
#define ENGINE_H

#include "Board.h"
#include "Move.h"

class Engine {
public:
    Move findBestMove(Board& board, int depth);

private:
    int alphaBeta(Board& board, int depth, int alpha, int beta, bool maximizingPlayer);

    // weitere Helferfunktionen, Bewertungsfunktion etc.
};

#endif#pragma once
