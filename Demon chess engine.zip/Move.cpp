
#include "Move.h"

Move::Move(int fr, int ff, int tr, int tf)
    : fromRank(fr), fromFile(ff), toRank(tr), toFile(tf) {}

std::string Move::toString() const {
    std::string s;
    s += (char)('a' + fromFile);
    s += (char)('1' + fromRank);
    s += "-";
    s += (char)('a' + toFile);
    s += (char)('1' + toRank);
    return s;
}
