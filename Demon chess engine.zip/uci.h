// uci.h
#ifndef UCI_H
#define UCI_H
void uciLoop();
#endif