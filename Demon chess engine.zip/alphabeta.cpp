#include "alphabeta.h"
int alphaBeta(int depth, int alpha, int beta, bool isMaximizingPlayer) {
    if (depth == 0 || gameOver())
        return evaluateBoard();

    if (isMaximizingPlayer) {
        int maxEval = INT_MIN;
        for (Move move : generateAllLegalMoves()) {
            makeMove(move);
            int eval = alphaBeta(depth - 1, alpha, beta, false);
            undoMove(move);
            maxEval = max(maxEval, eval);
            alpha = max(alpha, eval);
            if (beta <= alpha)
                break;  // Beta Cutoff
        }
        return maxEval;
    }
    else {
        int minEval = INT_MAX;
        for (Move move : generateAllLegalMoves()) {
            makeMove(move);
            int eval = alphaBeta(depth - 1, alpha, beta, true);
            undoMove(move);
            minEval = min(minEval, eval);
            beta = min(beta, eval);
            if (beta <= alpha)
                break;  // Alpha Cutoff
        }
        return minEval;
    }
}
int alphaBeta(Board& board, int depth, int alpha, int beta, bool maximizingPlayer) {
    if (depth == 0 || board.isGameOver()) {
        int materialEval = board.evaluateMaterial();
        int styleEval = evaluatePositionWithStyle(board);
        return materialEval + styleEval;
    }

    std::vector<Move> moves = generateAllLegalMoves(board);

    if (maximizingPlayer) {
        int maxEval = -INF;
        for (const Move& move : moves) {
            board.makeMove(move);
            int eval = alphaBeta(board, depth - 1, alpha, beta, false);
            board.undoMove(move);
            maxEval = std::max(maxEval, eval);
            alpha = std::max(alpha, eval);
            if (beta <= alpha)
                break; // Beta cutoff
        }
        return maxEval;
    }
    else {
        int minEval = INF;
        for (const Move& move : moves) {
            board.makeMove(move);
            int eval = alphaBeta(board, depth - 1, alpha, beta, true);
            board.undoMove(move);
            minEval = std::min(minEval, eval);
            beta = std::min(beta, eval);
            if (beta <= alpha)
                break; // Alpha cutoff
        }
        return minEval;
    }
}