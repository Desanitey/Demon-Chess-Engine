#include "eval.h"

int getPieceValue(Piece p) {
    switch (p) {
        case PAWN: return 100;
        case KNIGHT: return 320;
        case BISHOP: return 330;
        case ROOK: return 500;
        case QUEEN: return 900;
        case KING: return 20000;
        default: return 0;
    }
}

int evaluateMaterial(const Board& board) {
    int score = 0;
    for (int r = 0; r < 8; ++r) {
        for (int f = 0; f < 8; ++f) {
            Square sq = board.squares[r][f];
            int value = getPieceValue(sq.piece);
            if (sq.color == WHITE) score += value;
            else if (sq.color == BLACK) score -= value;
        }
    }
    return score;
}