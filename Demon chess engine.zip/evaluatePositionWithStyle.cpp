int evaluatePositionWithStyle(const Board& board) {
    int score = 0;

    // ----------------------------
    // 1. K�nigssicherheit des Gegners
    // ----------------------------
    int kingSquare = board.whiteToMove ? board.blackKing.square : board.whiteKing.square;
    int attackingPieces = countAttackers(kingSquare, board);
    score += attackingPieces * 15;

    // ----------------------------
    // 2. Angriff auf ungesch�tzte Figuren
    // ----------------------------
    std::vector<Piece> opponentPieces = board.whiteToMove ? board.blackPieces : board.whitePieces;
    for (const Piece& p : opponentPieces) {
        if (!isProtected(p.square, board)) {
            score += 10;
        }
    }

    // ----------------------------
    // 3. Druck auf ein Feld durch mehrere Figuren
    // ----------------------------
    for (int square = 0; square < 64; ++square) {
        int attackers = countAttackers(square, board);
        int defenders = countDefenders(square, board);
        if (attackers > defenders && attackers > 1) {
            score += (attackers - defenders) * 5;
        }
    }

    // ----------------------------
    // 4. Initiative: aktive Figuren
    // ----------------------------
    int activeMoves = generateAllLegalMoves(board).size();
    score += activeMoves / 2;

    return board.whiteToMove ? score : -score;
}
int countAttackers(int square, const Board& board) {
    // Z�hle wie viele eigene Figuren dieses Feld angreifen
    int count = 0;
    std::vector<Move> moves = generateAllLegalMoves(board);
    for (const Move& move : moves) {
        if (move.to == square)
            count++;
    }
    return count;
}

int countDefenders(int square, const Board& board) {
    // Wie viele verteidigen das Feld?
    Board flipped = board;
    flipped.whiteToMove = !board.whiteToMove;
    return countAttackers(square, flipped);
}

bool isProtected(int square, const Board& board) {
    return countDefenders(square, board) > 0;
}