
#include "MoveGenerator.h"

namespace MoveGenerator {
    std::vector<Move> generateAllLegalMoves(const Board& board) {
        std::vector<Move> moves;
        moves.push_back(Move(6, 4, 4, 4)); // Beispielzug: e2-e4
        return moves;
    }
}
