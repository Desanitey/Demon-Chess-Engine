// Search.cpp
#include "Search.h"

int Search::alphaBeta(int depth, int alpha, int beta) {
    // TODO: Alpha-Beta-Suche
    return 0;
}