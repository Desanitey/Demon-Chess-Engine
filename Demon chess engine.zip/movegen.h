#ifndef MOVEGEN_H
#define MOVEGEN_H

#include <vector>

struct Move {
    int from;
    int to;
    char promotion = 0;  // z. B. 'q', 'n', etc.
};

struct Board;

std::vector<Move> generate_all_moves(const Board& board, bool white_to_move);

#endif