
#ifndef MOVEGENERATOR_H
#define MOVEGENERATOR_H

#include "Board.h"
#include "Move.h"
#include <vector>

namespace MoveGenerator {
    std::vector<Move> generateAllLegalMoves(const Board& board);
}

#endif
