#pragma once
#include "board.h"

int evaluateMaterial(const Board& board);