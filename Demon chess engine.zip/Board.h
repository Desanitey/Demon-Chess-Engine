// Board.h
#ifndef BOARD_H
#define BOARD_H

class Board {
public:
    void loadFEN(const std::string,,,& fen);
    void print();
    void makeMove(const Move,,& move);
};

#endif