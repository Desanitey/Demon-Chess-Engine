#pragma once

int alphaBeta(int depth, int alpha, int beta, bool isMaximizingPlayer);
