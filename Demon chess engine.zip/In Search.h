#ifndef SEARCH_H
#define SEARCH_H

#include "Move.h"
#include "Board.h"

Move findBestMove(Board& board, int depth);

#endif
#pragma once

#include <limits>

class Search {
public:
    static int minimax(Board& board, int depth, int alpha, int beta, bool maximizingPlayer);
    static Move findBestMove(Board& board, int depth);
};
#pragma once

class Search {
public:
    static int alphaBeta(Board& board, int depth, int alpha, int beta, bool maximizingPlayer);
    static Move findBestMove(Board& board, int depth);
};