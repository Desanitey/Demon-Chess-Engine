// main.cpp
#include <iostream>
#include "Board.h"
#include "Search.h"

int main() {
    Board board;
    board.loadFEN("startpos");
    board.print();

    Search search;
    int eval = search.alphaBeta(3, -10000, 10000);
    std::cout << "Evaluation: " << eval << std::endl;

    return 0;
}