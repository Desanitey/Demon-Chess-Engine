// Board.cpp
#include "Board.h"
#include <iostream>

void Board::loadFEN(const std::string& fen) {
    // TODO: FEN laden
}

void Board::print() {
    std::cout << "Brett anzeigen" << std::endl;
}