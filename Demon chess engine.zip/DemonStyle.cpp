#include "DemonStyle.h"
#include "Evaluation.h"
#include <random>
#include <algorithm>

// Zufallsquelle f�r kontrollierte Kreativit�t
std::random_device rd;
std::mt19937 rng(rd());

// Beispiel: Stilbewertung eines Zuges
static int styleScore(const Board& board, const Move& move) {
    // Beispielsweise: Z�ge, die das Zentrum verlassen, sind interessanter
    int score = 0;
    if (move.to_x < 2 || move.to_x > 5 || move.to_y < 2 || move.to_y > 5)
        score += 10;

    // Weitere Beispiele: Opfer, Turmverdopplung, K�nigsexponierung, etc.
    // Wir k�nnen das mit der Zeit erweitern.

    return score;
}

// W�hle �interessanten� Zug aus allen legalen
Move selectStylishMove(const Board& board, const std::vector<Move>& legalMoves) {
    std::vector<std::pair<Move, int>> scoredMoves;
    for (const auto& move : legalMoves) {
        scoredMoves.push_back({ move, styleScore(board, move) });
    }

    // Sortieren nach StyleScore
    std::sort(scoredMoves.begin(), scoredMoves.end(), [](const auto& a, const auto& b) {
        return a.second > b.second;
        });

    // W�hle unter den Top-3 einen zuf�lligen Zug
    int range = std::min(3, (int)scoredMoves.size());
    std::uniform_int_distribution<int> dist(0, range - 1);
    return scoredMoves[dist(rng)].first;
}
int evaluatePositionWithStyle(const Board& board) {
    int score = 0;

    // Beispiel: K�nigsexponierung
    if (kingIsExposed(board, board.whiteToMove ? board.blackKing : board.whiteKing)) {
        score += 20;
    }

    // Beispiel: Gegnerbauernstruktur
    score += evaluateOpponentPawnStructure(board);

    // Beispiel: Zentrumskontrolle
    score += evaluateCenterControl(board);

    // (Optional): Bewertungsmodifikation je nach Spielphase

    return score;
}
static bool kingIsExposed(const Board& board, Square kingSquare) {
    int danger = 0;

    // Z�hle Anzahl gegnerischer Figuren, die in der N�he wirken
    for (const Move& move : generateAllLegalMoves(board)) {
        if (move.to == kingSquare ||
            isNeighboringSquare(move.to, kingSquare)) {
            danger++;
        }
    }

    return danger >= 3; // Wenn 3 oder mehr gegnerische Figuren Einfluss haben
}

static bool isNeighboringSquare(Square a, Square b) {
    int dx = abs((a % 8) - (b % 8));
    int dy = abs((a / 8) - (b / 8));
    return dx <= 1 && dy <= 1;
}
static int evaluateCenterControl(const Board& board) {
    int score = 0;
    std::vector<Square> center = { E4, D4, E5, D5 };

    for (const Move& move : generateAllLegalMoves(board)) {
        for (Square c : center) {
            if (move.to == c) {
                score += 2;
            }
        }
    }

    return score;
}
static nt evaluateOpponentPawnStructure(const Board& board) {
    int penalty = 0;

    const std::vector<Piece>& pawns = board.whiteToMove ? board.blackPawns : board.whitePawns;

    for (const Piece& pawn : pawns) {
        if (isIsolated(pawn, board)) penalty += 10;
        if (isDoubled(pawn, board)) penalty += 10;
    }

    return penalty;
}

// Dummy-Funktionen � m�chtest du, dass ich die auch direkt ausprogrammiere?
bool isIsolated(const Piece,& pawn, const Board& board);
bool isDoubled(const Piece& pawn, const Board& board);
int evaluatePositionWithStyle(const Board& board) {
    int score = 0;

    Square enemyKing = board.whiteToMove ? board.blackKing : board.whiteKing;

    if (kingIsExposed(board, enemyKing)) score += 20;

    score += evaluateCenterControl(board);

    score += evaluateOpponentPawnStructure(board);

    return score;
}