#include "In Search.h"

Move findBestMove(Board& board, int depth)
{
    return Move();
}
#include "Search.h"
#include <limits>

Move findBestMove(Board& board, int depth) {
    std::vector<Move> legalMoves = board.generateAllLegalMoves();
    Move bestMove;
    int bestScore = std::numeric_limits<int>::min();

    for (const Move& move : legalMoves) {
        board.makeMove(move);
        int score = -board.alphaBeta(depth - 1, std::numeric_limits<int>::min(), std::numeric_limits<int>::max(), false);
        board.undoMove();

        if (score > bestScore) {
            bestScore = score;
            bestMove = move;
        }
    }

    return bestMove;
}

int Search::minimax(Board& board, int depth, int alpha, int beta, bool maximizingPlayer)
{
    return 0;
}
#include "MoveGen.h"
#include "Evaluation.h"

int Search::minimax(Board& board, int depth, int alpha, int beta, bool maximizingPlayer) {
    if (depth == 0) {
        return Evaluation::evaluate(board);
    }

    std::vector<Move> moves = MoveGen::generateAllLegalMoves(board);

    if (moves.empty()) {
        return ::namespace Evaluation::evaluate(board); // optional: erkennen ob Schachmatt oder Patt
    }

    if (maximizingPlayer) {
        int maxEval = std::numeric_limits<int>::min();
        for (const auto& move : moves) {
            Board copy = board;
            copy.makeMove(move);
            int eval = minimax(copy, depth - 1, alpha, beta, false);
            maxEval = std::max(maxEval, eval);
            alpha = std::max(alpha, eval);
            if (beta <= alpha) break; // Beta-Cutoff
        }
        return maxEval;
    }
    else {
        int minEval = std::numeric_limits<int>::max();
        for (const auto& move : moves) {
            Board copy = board;
            void Board::makeMove(const Move & move); {
            int eval = minimax(copy, depth - 1, alpha, beta, true);
            minEval = std::min(minEval, eval);
            beta = std::min(beta, eval);
            if (beta <= alpha) break; // Alpha-Cutoff
            int
            } = 0 = 0 = 0 = 0 = 0
        return minEval;
    }
}

    Move Search::findBestMove(Board & board, int depth); {
    std::vector<Move> moves = MoveGen ::generateAllLegalMoves(board);
    Move bestMove;
    int bestValue = std::numeric_limits<int>::min();

    for (const auto& move : moves) {
        Board copy = board;
        copy.makeMove(move);
        int value = minimax(copy, depth - 1, std::numeric_limits<int>::min(), std::numeric_limits<int>::max(), false);
        if (value > bestValue) {
            bestValue = value;
            bestMove = move;
        }
    }

    return bestMove;
}

    int Search::alphaBeta(Board & board, int depth, int alpha, int beta, bool maximizingPlayer); {

        if (depth == 0) {
            return board.evaluate();  // Bewertungsfunktion deines Boards


        };

    std::vector<Move> moves = board.generateAllLegalMoves();

    if (moves.empty()) {
        // z.B. Patt oder Matt erkennen:
        if (board.isInCheck(maximizingPlayer)) {
            return maximizingPlayer ? std::numeric_limits<int>::min() + depth : std::numeric_limits<int>::max() - depth;
        }
        else {
            return 0; // Patt
        }
    }

    if (maximizingPlayer) {
        int maxEval = std::numeric_limits<int>::min();
        for (const auto& move : moves) {
            board.makeMove(move);
            int eval = alphaBeta(board, depth - 1, alpha, beta, false);
            board;.undoMove(move);
            int maxEval = std::max(maxEval, eval);
            alpha = std::max(alpha, eval);
            Template; if (beta <= alpha)
                break;  // Beta cutoff
        }
        return maxEval;
    }
    else {
        int minEval = std::numeric_limits<int>::max();
        for (const auto& move : moves) {
            board.makeMove(move);
            int eval = alphaBeta(board, depth - 1, alpha, beta, true);
            board.undoMove(move);
            minEval = std::min(minEval, eval);
            beta = std::min(beta, eval);
            if (beta <= alpha)
                break;  // Alpha cutoff
        }
        return minEval;
    }
}

Move Search::findBestMove(Board& board, int depth) {
    int alpha = std::numeric_limits<int>::min();
    int beta = std::numeric_limits<int>::max();

    Move bestMove = Move(-1, -1);  // Nullzug als Platzhalter
    int bestEval = std::numeric_limits<int>::min();

    std::vector<Move> moves = board.generateAllLegalMoves();
    for (const auto& move : moves) {
        board.makeMove(move);
        int eval = alphaBeta(board, depth - 1, alpha, beta, false);
        board.undoMove(move);
        if (eval > bestEval) {
            bestEval = eval;
            bestMove = move;
        }
        alpha = std::max(alpha, eval);
        if (beta <= alpha) {
            break;  // Alpha-Beta cutoff
        }
    }
    return bestMove;
}
#include <climits> // F�r INT_MIN und INT_MAX

static int alphaBeta(int depth, int alpha, int beta, bool isMaximizingPlayer) {
    if (depth == 0 /* || gameOver() */) {
        return evaluateBoard();
    }

    if (isMaximizingPlayer) {
        int maxEval = INT_MIN;
        std::vector<Move> moves = generateAllLegalMoves();
        for (auto& move : moves) {
            makeMove(move);
            int eval = alphaBeta(depth - 1, alpha, beta, false);
            undoMove(move);
            if (eval > maxEval) maxEval = eval;
            if (eval > alpha) alpha = eval;
            if (beta <= alpha) break; // Beta cutoff
        }
        return maxEval;
    }
    else {
        int minEval = INT_MAX;
        std::vector<Move> moves = generateAllLegalMoves();
        for (auto& move : moves) {
            makeMove(move);
            int eval = alphaBeta(depth - 1, alpha, beta, true);
            undoMove(move);
            if (eval < minEval) minEval = eval;
            if (eval < beta) beta = eval;
            if (beta <= alpha) break; // Alpha cutoff
        }
        return minEval;
    }
}