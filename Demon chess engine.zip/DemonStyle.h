#pragma once
#include "Move.h"
#include "Board.h"
#include <vector>

Move selectStylishMove(const Board& board, const std::vector<Move>& legalMoves);
int evaluatePositionWithStyle(const Board& board); #pragma once
