// uci.cpp
#include <iostream>
void uciLoop() {
    std::string command;
    while (std::getline(std::cin, command)) {
        if (command == "uci") {
            std::cout << "id name Demon\n";
            std::cout << "uciok\n";
        }
    }
}