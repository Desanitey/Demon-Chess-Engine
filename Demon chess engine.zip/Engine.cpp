#include "Engine.h"
#include <limits>
#include "movegen.cpp"

Move Engine::findBestMove(Board& board, int depth) {
    int bestScore = std::numeric_limits<int>::min();
    Move bestMove;

    auto legalMoves = board.generateAllLegalMoves(); // Deine Funktion zum Zug-Generieren

    for (const auto& move : legalMoves) {
        board.makeMove(move);

        int score = alphaBeta(board, depth - 1, std::numeric_limits<int>::min(), std::numeric_limits<int>::max(), false);

        board.undoMove(move);

        if (score > bestScore) {
            bestScore = score;
            bestMove = move;
        }
    }

    return bestMove;
}

int Engine::alphaBeta(Board& board, int depth, int alpha, int beta, bool maximizingPlayer) {
    if (depth == 0 || board.isGameOver()) {
        return board.evaluate();  // Deine Bewertungsfunktion
    }

    auto legalMoves = board.generateAllLegalMoves();

    if (maximizingPlayer) {
        int maxEval = std::numeric_limits<int>::min();
        for (const auto& move : legalMoves) {
            board.makeMove(move);
            int eval = alphaBeta(board, depth - 1, alpha, beta, false);
            board.undoMove(move);
            maxEval = std::max(maxEval, eval);
            alpha = std::max(alpha, eval);
            if (beta <= alpha) {
                break;  // Beta Cutoff
            }
        }
        return maxEval;
    }
    else {
        int minEval = std::numeric_limits<int>::max();
        for (const auto& move : legalMoves) {
            board.makeMove(move);
            int eval = alphaBeta(board, depth - 1, alpha, beta, true);
            board.undoMove(move);
            minEval = std::min(minEval, eval);
            beta = std::min(beta, eval);
            if (beta <= alpha) {
                break;  // Alpha Cutoff
            }
        }
        return minEval;
    }
}