#pragma once inline int evaluate(const Board& board) {
int score = 0;

// Materialbewertung
for (int i = 0; i < 64; ++i) {
    Piece p = board.squares[i];
    int value = getPieceValue(p.type);
    if (value == 0) continue;

    if (p.color == WHITE)
        score += value;
    else
        score -= value;

    // Bonus f�r Zentrumskontrolle
    if (p.type != PAWN && (i == 27 || i == 28 || i == 35 || i == 36)) {
        if (p.color == WHITE) score += 10;
        else score -= 10;
    }

    // Bonus f�r Entwicklung (Springer & L�ufer nicht auf Grundreihe)
    if ((p.type == KNIGHT || p.type == BISHOP) && (i < 8 || i >= 56)) {
        if (p.color == WHITE) score -= 20;
        else score += 20;
    }
}

return score;
}
