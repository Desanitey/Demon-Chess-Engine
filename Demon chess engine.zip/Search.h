// Search.h
#ifndef SEARCH_H
#define SEARCH_H

class Search {
public:
    int alphaBeta(int depth, int alpha, int beta);
};

#endif