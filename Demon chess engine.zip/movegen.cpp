#include "movegen.h"
#include "board.h"

const int knight_offsets[8][2] = {
    { 1, 2}, { 2, 1}, {-1, 2}, {-2, 1},
    {-2,-1}, {-1,-2}, { 2,-1}, { 1,-2}
};

const int bishop_directions[4][2] = {
    { 1, 1}, { 1,-1}, {-1, 1}, {-1,-1}
};

const int rook_directions[4][2] = {
    { 1, 0}, {-1, 0}, { 0, 1}, { 0,-1}
};

static int to_index(int row, int col) {
    return row * 8 + col;
}

static bool in_bounds(int row, int col) {
    return row >= 0 && row < 8 && col >= 0 && col < 8;
}

static bool is_white_piece(char piece) {
    return piece >= 'A' && piece <= 'Z';
}

static bool is_black_piece(char piece) {
    return piece >= 'a' && piece <= 'z';
}

static std::vector<Move> generate_knight_moves(const Board& board, int from, bool white_to_move) {
    std::vector<Move> moves;
    int row = from / 8, col = from % 8;
    for (auto& offset : knight_offsets) {
        int r = row + offset[0], c = col + offset[1];
        if (!in_bounds(r, c)) continue;
        int to = to_index(r, c);
        char target = board.squares[to];
        if ((white_to_move && is_white_piece(target)) || (!white_to_move && is_black_piece(target)))
            continue;
        moves.push_back({from, to});
    }
    return moves;
}

static std::vector<Move> generate_sliding_moves(const Board& board, int from, bool white_to_move, const int directions[][2], int dir_count) {
    std::vector<Move> moves;
    int row = from / 8, col = from % 8;
    for (int i = 0; i < dir_count; ++i) {
        int r = row, c = col;
        while (true) {
            r += directions[i][0];
            c += directions[i][1];
            if (!in_bounds(r, c)) break;
            int to = to_index(r, c);
            char target = board.squares[to];
            if ((white_to_move && is_white_piece(target)) || (!white_to_move && is_black_piece(target)))
                break;
            moves.push_back({from, to});
            if (target != '.') break;  // capture ends direction
        }
    }
    return moves;
}

static std::vector<Move> generate_pawn_moves(const Board& board, int from, bool white_to_move) {
    std::vector<Move> moves;
    int dir = white_to_move ? -1 : 1;
    int row = from / 8, col = from % 8;
    int fwd = to_index(row + dir, col);
    if (in_bounds(row + dir, col) && board.squares[fwd] == '.') {
        moves.push_back({from, fwd});
        if ((white_to_move && row == 6) || (!white_to_move && row == 1)) {
            int dbl = to_index(row + 2 * dir, col);
            if (board.squares[dbl] == '.') moves.push_back({from, dbl});
        }
    }
    for (int dc = -1; dc <= 1; dc += 2) {
        int tc = col + dc;
        int tr = row + dir;
        if (!in_bounds(tr, tc)) continue;
        int to = to_index(tr, tc);
        char target = board.squares[to];
        if (target != '.' && ((white_to_move && is_black_piece(target)) || (!white_to_move && is_white_piece(target)))) {
            moves.push_back({from, to});
        }
    }
    return moves;
}

static std::vector<Move> generate_king_moves(const Board& board, int from, bool white_to_move) {
    std::vector<Move> moves;
    int row = from / 8, col = from % 8;
    for (int dr = -1; dr <= 1; ++dr) {
        for (int dc = -1; dc <= 1; ++dc) {
            if (dr == 0 && dc == 0) continue;
            int r = row + dr, c = col + dc;
            if (!in_bounds(r, c)) continue;
            int to = to_index(r, c);
            char target = board.squares[to];
            if ((white_to_move && is_white_piece(target)) || (!white_to_move && is_black_piece(target)))
                continue;
            moves.push_back({from, to});
        }
    }
    return moves;
}

std::vector<Move> generate_all_moves(const Board& board, bool white_to_move) {
    std::vector<Move> moves;
    for (int i = 0; i < 64; ++i) {
        char p = board.squares[i];
        if (p == '.') continue;
        if (white_to_move && !is_white_piece(p)) continue;
        if (!white_to_move && !is_black_piece(p)) continue;

        std::vector<Move> piece_moves;
        switch (tolower(p)) {
            case 'p': piece_moves = generate_pawn_moves(board, i, white_to_move); break;
            case 'n': piece_moves = generate_knight_moves(board, i, white_to_move); break;
            case 'b': piece_moves = generate_sliding_moves(board, i, white_to_move, bishop_directions, 4); break;
            case 'r': piece_moves = generate_sliding_moves(board, i, white_to_move, rook_directions, 4); break;
            case 'q': {
                piece_moves = generate_sliding_moves(board, i, white_to_move, bishop_directions, 4);
                auto rook_part = generate_sliding_moves(board, i, white_to_move, rook_directions, 4);
                piece_moves.insert(piece_moves.end(), rook_part.begin(), rook_part.end());
                break;
            }
            case 'k': piece_moves = generate_king_moves(board, i, white_to_move); break;
        }
        moves.insert(moves.end(), piece_moves.begin(), piece_moves.end());
    }
    return moves;
}
void MoveGenerator::generatePawnMoves(const Board& board, int row, int col, std::vector<Move>& moves) {
    Piece piece = board.squares[row][col];
    if (piece.type != PieceType::Pawn || piece.color != board.sideToMove)
        return;

    int direction = (piece.color == Color::White) ? -1 : 1;
    int startRow = (piece.color == Color::White) ? 6 : 1;
    int promotionRow = (piece.color == Color::White) ? 0 : 7;

    // Einzelner Vorw�rtsschritt
    int nextRow = row + direction;
    if (board.isInsideBoard(nextRow, col) && board.squares[nextRow][col].type == PieceType::None) {
        if (nextRow == promotionRow) {
            // Umwandlung
            moves.emplace_back(row, col, nextRow, col, piece, Piece(PieceType::Queen, piece.color));
            moves.emplace_back(row, col, nextRow, col, piece, Piece(PieceType::Rook, piece.color));
            moves.emplace_back(row, col, nextRow, col, piece, Piece(PieceType::Bishop, piece.color));
            moves.emplace_back(row, col, nextRow, col, piece, Piece(PieceType::Knight, piece.color));
        }
        else {
            moves.emplace_back(row, col, nextRow, col, piece);
        }

        // Doppelschritt vom Startfeld
        if (row == startRow) {
            int doubleStepRow = row + 2 * direction;
            if (board.squares[doubleStepRow][col].type == PieceType::None) {
                moves.emplace_back(row, col, doubleStepRow, col, piece);
            }
        }
    }

    // Schlagz�ge (Diagonal links und rechts)
    for (int dcol = -1; dcol <= 1; dcol += 2) {
        int targetCol = col + dcol;
        if (!board.isInsideBoard(nextRow, targetCol)) continue;

        Piece targetPiece = board.squares[nextRow][targetCol];
        if (targetPiece.type != PieceType::None && targetPiece.color != piece.color) {
            if (nextRow == promotionRow) {
                // Umwandlung mit Schlag
                moves.emplace_back(row, col, nextRow, targetCol, piece, Piece(::PieceType::Queen, piece.color));
                moves.emplace_back(row, col, nextRow, targetCol, piece, Piece(::PieceType::Rook, piece.color));
                moves.emplace_back(row, col, nextRow, targetCol, piece, Piece(::PieceType::Bishop, piece.color));
                moves.emplace_back(row, col, nextRow, targetCol, piece, Piece(:: PieceType::Knight, piece.color));
            }
            else {
                moves.emplace_back(row, col, nextRow, targetCol, piece, targetPiece);
            }
        }
    }
#include "Board.h"
#include "Move.h"
#include <vector>

    // Hilfsfunktionen:
    // board.isOnBoard(int square) --> Pr�ft, ob Feld g�ltig (0..63)
    // board.isOccupied(int square) --> Pr�ft, ob Feld besetzt
    // board.getPieceColor(int square) --> Gibt Farbe der Figur zur�ck
    // board.isSameColor(int square, int color) --> Pr�ft Farbe
    // board.canCastleKingSide(int color), canCastleQueenSide(int color)
    // board.isSquareAttacked(int square, int opponentColor)

    // Erzeugt L�uferz�ge (diagonal)
    static void generateBishopMoves(const Board & board, int square, std::vector<Move>&moves); {
        const int directions[4] = { 9, 7, -9, -7 }; // Diagonale
        int pieceColor = board.getPieceColor(square);

        for (int dir : directions) {
            int targetSquare = square + dir;
            while (board.isOnBoard(targetSquare) && !board.isSameColor(targetSquare, pieceColor)) {
                moves.push_back(Move(square, targetSquare));
                if (board.isOccupied(targetSquare)) break;  // Schlagzug
                targetSquare += dir;
            }
        }
    }

    // Erzeugt Damen-Z�ge (alle 8 Richtungen)
    static void generateQueenMoves(const Board & board, int square, std::vector<Move>&moves); {
        const int directions[8] = { 1, -1, 8, -8, 9, 7, -9, -7 };
        int pieceColor = board.getPieceColor(square);

        for (int dir : directions) {
            int targetSquare = square + dir;
            while (board.isOnBoard(targetSquare) && !board.isSameColor(targetSquare, pieceColor)) {
                moves.push_back(Move(square, targetSquare));
                if (board.isOccupied(targetSquare)) break;
                targetSquare += dir;
            }
        }
    }

    // Erzeugt K�nigsz�ge (1 Feld in alle Richtungen)
    static void generateKingMoves(const Board & board, int square, std::vector<Move>&moves) {
        const int directions[8] = { 1, -1, 8, -8, 9, 7, -9, -7 };
        int pieceColor = board.getPieceColor(square);

        for (int dir : directions) {
            int targetSquare = square + dir;
            if (board.isOnBoard(targetSquare) && !board.isSameColor(targetSquare, pieceColor)) {
                moves.push_back(Move(square, targetSquare));
            }
        }
    }

    // Rochade (vereinfacht, nur Standard-Regeln ohne Spezialf�lle)
    static void generateCastlingMoves(const Board & board, int square, std::vector<Move>&moves) {
        int pieceColor = board.getPieceColor(square);

        if (pieceColor == WHITE) {
            // Kurze Rochade (Wei�)
            if (board.canCastleKingSide(WHITE) &&
                !board.isOccupied(5) && !board.isOccupied(6) &&
                !board.isSquareAttacked(4, BLACK) &&
                !board.isSquareAttacked(5, BLACK) &&
                !board.isSquareAttacked(6, BLACK)) {
                moves.push_back(Move(4, 6, Move::CASTLING));
            }
            // Lange Rochade (Wei�)
            if (board.canCastleQueenSide(WHITE) &&
                !board.isOccupied(1) && !board.isOccupied(2) && !board.isOccupied(3) &&
                !board.isSquareAttacked(4, BLACK) &&
                !board.isSquareAttacked(3, BLACK) &&
                !board.isSquareAttacked(2, BLACK)) {
                moves.push_back(Move(4, 2, Move::CASTLING));
            }
        }
        else {
            // Kurze Rochade (Schwarz)
            if (board.canCastleKingSide(BLACK) &&
                !board.isOccupied(61) && !board.isOccupied(62) &&
                !board.isSquareAttacked(60, WHITE) &&
                !board.isSquareAttacked(61, WHITE) &&
                !board.isSquareAttacked(62, WHITE)) {
                moves.push_back(Move(60, 62, Move::CASTLING));
            }
            // Lange Rochade (Schwarz)
            if (board.canCastleQueenSide(BLACK) &&
                !board.isOccupied(57) && !board.isOccupied(58) && !board.isOccupied(59) &&
                !board.isSquareAttacked(60, WHITE) &&
                !board.isSquareAttacked(59, WHITE) &&
                !board.isSquareAttacked(58, WHITE)) {
                moves.push_back(Move(60, 58, Move::CASTLING));
            }
        }
    }

    // Gesamt-Funktion um alle Z�ge zu generieren (alle Figuren inklusive Rochade)
    static void generateAllLegalMoves(const Board & board, std::vector<Move>&moves) {
        moves.clear();
        for (int square = 0; square < 64; ++square) {
            int piece = board.getPiece(square);
            if (piece == EMPTY) continue;

            int pieceType = board.getPieceType(piece);
            int pieceColor = board.getPieceColor(piece);

            switch (pieceType) {
            case BISHOP:
                generateBishopMoves(board, square, moves);
                break;
            case QUEEN:
                generateQueenMoves(board, square, moves);
                break;
            case KING:
                generateKingMoves(board, square, moves);
                generateCastlingMoves(board, square, moves);
                break;
                // andere Figuren (Springer, Turm, Bauer) schon fertig?
            default:
                break;
            }
        }
    }