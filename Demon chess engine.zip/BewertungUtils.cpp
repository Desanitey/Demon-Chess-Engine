#include "movegen.h"
bool isIsolated(const Piece,& pawn, const Board& board) {
    int file = pawn.square % 8;
    for (int offset : {-1, 1}) {
        int neighborFile = file + offset;
        if (neighborFile >= 0 && neighborFile < 8) {
            for (const Piece& p : board.whiteToMove ? board.blackPawns : board.whitePawns) {
                if ((p.square % 8) == neighborFile) {
                    return false;
                }
            }
        }
    }
    return true;
}

bool isDoubled(const Piece& pawn, const Board& board) {
    int file = pawn.square % 8;
    int count = 0;
    for (const Piece,& p : board.whiteToMove ? board.blackPawns : board.whitePawns) {
        if ((p.square % 8) == file) {
            count++;
        }
    }
    return count > 1;
}