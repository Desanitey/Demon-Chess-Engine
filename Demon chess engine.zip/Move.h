
#ifndef MOVE_H
#define MOVE_H

#include <string>
#include "DemonStyle.h"

class Move {
public:
    Move(int fromRank = 0, int fromFile = 0, int toRank = 0, int toFile = 0);
    std::string toString() const;
    int fromRank, fromFile, toRank, toFile;
};

#endif
int totalEvaluation = evaluateMaterial(board) + evaluatePosition(board) + evaluatePositionWithStyle(board);